package com.letslearnspringwithmaven.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.util.Arrays;

@SpringBootApplication
public class ExampleSpringProjectApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(ExampleSpringProjectApplication.class, args);

		RecommenderImplementation recommender = context.getBean(RecommenderImplementation.class);

		String[] recommendationsForUserOne = recommender.getContentBasedRecommendations("Transporter");
		String[] recommendationsForUserTwo = recommender.getCollaborativeRecommendations("Transporter");

		System.out.println("User One : " + Arrays.asList(recommendationsForUserOne));
		System.out.println("User Two : " + Arrays.asList(recommendationsForUserTwo));

		System.out.println("Generic Movies : " + Arrays.asList(recommender.getRecommendations("Transporter")));
	}
}
