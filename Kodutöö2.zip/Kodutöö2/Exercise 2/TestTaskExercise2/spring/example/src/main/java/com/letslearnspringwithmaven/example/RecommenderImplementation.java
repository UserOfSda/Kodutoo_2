package com.letslearnspringwithmaven.example;

import com.letslearnspringwithmaven.example.filter.Filter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class RecommenderImplementation {

    private Filter filter;

//    public RecommenderImplementation(@Qualifier("ContentBasedFilter") Filter filter) {
//        this.filter = filter;
//    }

    //    @Autowired
//    private Filter collaborativeFilter;

//    @Autowired
//    private Filter contentBasedFilter;

    public String[] getRecommendations(String movie) {
        return filter.getMoviesByName(movie);
    }

    public String[] getContentBasedRecommendations(String movie) {
        return new String[]{};
//        return contentBasedFilter.getMoviesByName(movie);
    }

    public String[] getCollaborativeRecommendations(String movie) {
        return new String[]{};
//        return collaborativeFilter.getMoviesByName(movie);
    }

    @Autowired
    @Qualifier("contentBasedFilter")
    public void setFilter(Filter filter) {
        this.filter = filter;
    }
}