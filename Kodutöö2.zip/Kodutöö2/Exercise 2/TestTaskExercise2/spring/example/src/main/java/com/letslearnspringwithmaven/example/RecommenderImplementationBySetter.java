package com.letslearnspringwithmaven.example;

import com.letslearnspringwithmaven.example.filter.Filter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class RecommenderImplementationBySetter {

    private Filter filter;

    @Autowired
    @Qualifier("contentBasedFilter")
    public void setFilter(Filter filter) {
        this.filter = filter;
    }

    public String[] getRecommendations(String movie) {
        return filter.getMoviesByName(movie);
    }
}