package com.letslearnspringwithmaven.example.filter;

public interface Filter {
    String[] getMoviesByName(String movie);
}
