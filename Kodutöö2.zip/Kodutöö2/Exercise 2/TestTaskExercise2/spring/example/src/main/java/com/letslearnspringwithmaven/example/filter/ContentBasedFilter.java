package com.letslearnspringwithmaven.example.filter;

import org.springframework.stereotype.Component;

@Component
public class ContentBasedFilter implements Filter {

    @Override
    public String[] getMoviesByName(String movie) {
        return new String[] {"John Wick", "Baby Driver", "Fast and Furious"};
    }
}
