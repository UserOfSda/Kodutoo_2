package com.letslearnspringwithmaven.example;

import com.letslearnspringwithmaven.example.filter.Filter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class RecommenderImplementationByField {

    @Autowired
    private Filter collaborativeFilter;

    @Autowired
    private Filter contentBasedFilter;

    public String[] getContentBasedRecommendations(String movie) {
        return contentBasedFilter.getMoviesByName(movie);
    }

    public String[] getCollaborativeRecommendations(String movie) {
        return collaborativeFilter.getMoviesByName(movie);
    }
}