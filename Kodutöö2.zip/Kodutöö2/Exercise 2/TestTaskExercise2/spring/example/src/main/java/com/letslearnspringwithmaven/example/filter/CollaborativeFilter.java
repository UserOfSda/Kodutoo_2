package com.letslearnspringwithmaven.example.filter;

import org.springframework.stereotype.Component;

@Component
public class CollaborativeFilter implements Filter {
    @Override
    public String[] getMoviesByName(String movie) {
        return new String[] {"John Wick 1", "John Wick 2", "John Wick 3"};
    }
}