package com.letslearnspringwithmaven.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleSpringProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
