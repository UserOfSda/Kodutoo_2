package com.messenger.art.service;

import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Locale;

@Service
public class MessageService {

    public String getMessage() {
        return "Please rephrase the question.";
    }

    public String getMessage(String... message) {
        if (message.length == 1 && message[0].toLowerCase(Locale.ROOT).equals("hello")) {
            return "Hello, How are you doing?";
        } else if (message.length > 2) {
            if (Arrays.toString(message).toLowerCase(Locale.ROOT).equals("how are you doing")) {
                return "I am good. Thanks you!";
            }
        }

        return "I don't know answer to this question!";
    }
}
