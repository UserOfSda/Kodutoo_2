package com.messenger.art;

import com.messenger.art.service.MessageService;
import com.messenger.art.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import static java.lang.System.exit;

@SpringBootApplication
public class ArtApplication implements CommandLineRunner {

	@Autowired
	MessageService messageService;

	@Autowired
	UserService userService;

	public static void main(String[] args) {
		SpringApplication springApplication = new SpringApplication(ArtApplication.class);
		springApplication.run(args);
	}

	@Override
	public void run(String... args) {
		System.out.println("The command line messenger is booting up...");
		if (args.length > 0) {
			System.out.println(messageService.getMessage(args));
		} else {
			System.out.println(messageService.getMessage());
		}

		exit(0);
	}
}
