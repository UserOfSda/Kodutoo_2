package com.messenger.art.component;

import org.springframework.stereotype.Component;

@Component
public class User {
    //Spring Data - JPA
}
