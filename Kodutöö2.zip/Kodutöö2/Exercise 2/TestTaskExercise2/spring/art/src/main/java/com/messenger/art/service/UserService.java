package com.messenger.art.service;

import com.messenger.art.component.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private User user;
}
