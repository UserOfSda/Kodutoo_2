package Example1.tabels;

import java.util.Date;

public class PatientRecords {
    private int pn;
    private String last;
    private String first;
    private String insurance_name;
    private Date i_from_date;
    private Date i_to_date;

    public PatientRecords(int pn, String last, String first, String insurance_name, Date i_from_date, Date i_to_date) {
        this.pn = pn;
        this.last = last;
        this.first = first;
        this.insurance_name = insurance_name;
        this.i_from_date = i_from_date;
        this.i_to_date = i_to_date;
    }

    public int getPn() {
        return pn;
    }

    public void setPn(int pn) {
        this.pn = pn;
    }

    public String getLast() {
        return last;
    }

    public void setLast(String last) {
        this.last = last;
    }

    public String getFirst() {
        return first;
    }

    public void setFirst(String first) {
        this.first = first;
    }

    public String getInsurance_name() {
        return insurance_name;
    }

    public void setInsurance_name(String insurance_name) {
        this.insurance_name = insurance_name;
    }

    public Date getI_from_date() {
        return i_from_date;
    }

    public void setI_from_date(Date i_from_date) {
        this.i_from_date = i_from_date;
    }

    public Date getI_to_date() {
        return i_to_date;
    }

    public void setI_to_date(Date i_to_date) {
        this.i_to_date = i_to_date;
    }

    @Override
    public String toString() {
        return "PatientRecords{" +
                "pn=" + pn +
                ", last='" + last + '\'' +
                ", first='" + first + '\'' +
                ", insurance_name='" + insurance_name + '\'' +
                ", i_from_date=" + i_from_date +
                ", i_to_date=" + i_to_date +
                '}';
    }
}
