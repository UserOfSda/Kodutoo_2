package Example1.main;
import Example1.tabels.Patient;
import javax.persistence.*;
import java.util.List;

public class Main {

    private static EntityManagerFactory ENTITY_MANAGER_FACTORY = Persistence.createEntityManagerFactory("test_task_database");
    private EntityManager entityManager;

    public static void main(String[] args) {
        getPatients();


    }

    public static void getPatients() {
        EntityManager em = ENTITY_MANAGER_FACTORY.createEntityManager();
        String strQuery = "FROM Patient ORDER BY last";
        TypedQuery<Patient> tqs = em.createQuery(strQuery, Patient.class);
        List<Patient> patients;
        try {
            patients = tqs.getResultList();
            patients.forEach(records -> System.out.println(records.getPn() + " " + records.getLast() + " " + records.getFirst() + " " + records.getDob()));
        } catch (NoResultException ex) {
            ex.printStackTrace();
        } finally {
            em.close();
        }
    }

    public List<Patient> patientList(String recordsName) {
//        String sql="SELECT p.pn,p.last,p.first,i.iname,i.from_date,i.to_date FROM patient p INNER JOIN insurance i ON p.patient_id=i.patient_id ORDER BY from_date";
        String sql = "from Patient p WHERE p.insurance.patient_id =:patient_id";

        return entityManager
                .createQuery(sql, Patient.class)
                .setParameter("id", recordsName)
                .getResultList();
    }
}
