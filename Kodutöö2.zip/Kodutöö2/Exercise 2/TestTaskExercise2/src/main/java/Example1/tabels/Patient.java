package Example1.tabels;


import javax.persistence.*;
import java.util.Date;



@Entity
@Table(name = "patient")
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "patient_id")
    private int patient_id;
    @Column(name = "pn")
    private int pn;
    @Column(name = "first")
    private String first;
    @Column(name = "last")
    private String last;
    @Column(name = "dob")
    private Date dob;

    @ManyToOne
    @JoinColumn(name="insurance_id")
    private Insurance insurance;

    public Patient(int patient_id, int pn, String first, String last, Date dob) {
        this.patient_id = patient_id;
        this.pn = pn;
        this.first = first;
        this.last = last;
        this.dob = dob;
    }

    public Patient(Insurance insurance) {
        this.insurance = insurance;
    }

    public Insurance getInsurance() {
        return insurance;
    }

    public void setInsurance(Insurance insurance) {
        this.insurance = insurance;
    }

    public Patient() {
    }

    public int getPatient_id() {
        return patient_id;
    }

    public void setPatient_id(int patient_id) {
        this.patient_id = patient_id;
    }

    public int getPn() {
        return pn;
    }

    public void setPn(int pn) {
        this.pn = pn;
    }

    public String getFirst() {
        return first;
    }

    public void setFirst(String first) {
        this.first = first;
    }

    public String getLast() {
        return last;
    }

    public void setLast(String last) {
        this.last = last;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    @Override
    public String toString() {
        return "Patient{" +
                "patient_id=" + patient_id +
                ", pn=" + pn +
                ", first='" + first + '\'' +
                ", last='" + last + '\'' +
                ", dob=" + dob +
                '}';
    }
}
