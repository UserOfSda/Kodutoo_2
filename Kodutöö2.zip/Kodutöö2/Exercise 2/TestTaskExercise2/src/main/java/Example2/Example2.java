package Example2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class Example2 {
    public static void main(String args[]) {

        String names = "John Smith John Doe";
        String name = names.replaceAll("\\s", "").toUpperCase();
        int stringLength = name.length();
        int count = 0;
        for (int i = 0; i < name.length(); i++) {
            if (Character.isLetter(name.charAt(i)))
                count++;
        }

        HashMap<Character, Integer> charMap = new HashMap<>();

        char[] charArray = name.toCharArray();
        for (int i = 0; i < charArray.length; i++) {
            if (charMap.containsKey(charArray[i])) {
                charMap.put(charArray[i], charMap.get(charArray[i]) + 1);

            } else {
                charMap.put(charArray[i], 1);
            }
        }

        ArrayList<Character> charList = new ArrayList<>();

        for (Map.Entry<Character, Integer> entry : charMap.entrySet()) {
            charList.add(entry.getKey());
        }
        Collections.sort(charList);

        for (int i = 0; i < charList.size(); i++) {
            float num = charMap.get(charList.get(i));
            System.out.println(charList.get(i) + ("\t") + charMap.get(charList.get(i)) + ("\t") + ((num / (count)) * 100 + " %"));
        }
    }
}


