package model;

import javax.persistence.EntityManager;
import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Entity
@Table(name = "patient")
public class Patient implements PatientRecord {

    private static EntityManagerFactory ENTITY_MANAGER_FACTORY;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "patient_id", unique = true)
    private int patient_id;
    @Column(name = "pn")
    private int pn;
    @Column(name = "first")
    private String first;
    @Column(name = "last")
    private String last;
    @Column(name = "dob")
    private Date dob;

//    private List<Patient> insuranceRecord = new ArrayList<>();

    public Patient(int patient_id, int pn, String first, String last, Date dob) {
        this.patient_id = patient_id;
        this.pn = pn;
        this.first = first;
        this.last = last;
        this.dob = dob;
    }

    public Patient() {
    }

    public int getPatient_id() {
        return patient_id;
    }

    public void setPatient_id(int patient_id) {
        this.patient_id = patient_id;
    }

    public int getPn() {
        return pn;
    }

    public void setPn(int pn) {
        this.pn = pn;
    }

    public String getFirst() {
        return first;
    }

    public void setFirst(String first) {
        this.first = first;
    }

    public String getLast() {
        return last;
    }

    public void setLast(String last) {
        this.last = last;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

//    public Patient(List<Patient> insuranceRecord) {
//        this.insuranceRecord = insuranceRecord;
//    }
//
//    public List<Patient> getInsuranceRecord() {
//        return insuranceRecord;
//    }
//
//    public void setInsuranceRecord(List<Patient> insuranceRecord) {
//        this.insuranceRecord = insuranceRecord;
//    }

    @Override
    public String toString() {
        return "Patient{" +
                "patient_id=" + patient_id +
                ", pn=" + pn +
                ", first='" + first + '\'' +
                ", last='" + last + '\'' +
                ", dob=" + dob +
                '}';
    }
}
