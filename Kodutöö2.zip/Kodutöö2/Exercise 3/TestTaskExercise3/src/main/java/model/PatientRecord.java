package model;

public interface PatientRecord {
}