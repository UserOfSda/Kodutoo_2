package model;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
//@Table(name = "insurance")
public class Insurance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "insurance_id", unique = true)
    private int insurance_id;
    @Column(name = "patient_id")
    private int patient_id;
    @Column(name = "iname")
    private String iname;
    @Column(name = "from_date")
    private Date from_date;
    @Column(name = "to_date")
    private Date to_date;

    public Insurance(int insurance_id, int patient_id, String iname, Date from_date, Date to_date) {
        this.insurance_id = insurance_id;
        this.patient_id = patient_id;
        this.iname = iname;
        this.from_date = from_date;
        this.to_date = to_date;
    }

    public Insurance() {
    }

    public int getInsurance_id() {
        return insurance_id;
    }

    public void setInsurance_id(int insurance_id) {
        this.insurance_id = insurance_id;
    }

    public int getPatient_id() {
        return patient_id;
    }

    public void setPatient_id(int patient_id) {
        this.patient_id = patient_id;
    }

    public String getIname() {
        return iname;
    }

    public void setIname(String iname) {
        this.iname = iname;
    }

    public Date getFrom_date() {
        return from_date;
    }

    public void setFrom_date(Date from_date) {
        this.from_date = from_date;
    }

    public Date getTo_date() {
        return to_date;
    }

    public void setTo_date(Date to_date) {
        this.to_date = to_date;
    }

    @Override
    public String toString() {
        return "Insurance{" +
                "insurance_id=" + insurance_id +
                ", patient_id=" + patient_id +
                ", iname='" + iname + '\'' +
                ", from_date=" + from_date +
                ", to_date=" + to_date +
                '}';
    }
}
