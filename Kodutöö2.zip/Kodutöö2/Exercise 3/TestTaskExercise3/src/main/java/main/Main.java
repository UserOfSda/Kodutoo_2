package main;

import model.Patient;
import javax.persistence.*;

public class Main {

    private static EntityManagerFactory ENTITY_MANAGER_FACTORY = Persistence.createEntityManagerFactory("test_task_database");

    public static void main(String[] args) {
        getPatientId(3);
        getPatientPn(5);
        findByNameAndLastName("John","Smith");

    }

    private static void getPatientPn(int pn) {
        EntityManager em = ENTITY_MANAGER_FACTORY.createEntityManager();
        String query = "SELECT p FROM Patient p WHERE p.pn = :patientnr";
        TypedQuery<Patient> tq = em.createQuery(query, Patient.class);
        tq.setParameter("patientnr", pn);
        Patient patient = null;
        try {
            patient = tq.getSingleResult();
            System.out.println(patient.getPatient_id() + " " + patient.getPn() + " " + patient.getFirst() + " " + patient.getLast() + " " + patient.getDob());
        } catch (NoResultException ex) {
            ex.printStackTrace();
        } finally {
            em.close();
        }
    }

    public static void getPatientId(int patient_id) {
        EntityManager em = ENTITY_MANAGER_FACTORY.createEntityManager();
        String query = "SELECT p FROM Patient p WHERE p.patient_id = :id";
        TypedQuery<Patient> tq = em.createQuery(query, Patient.class);
        tq.setParameter("id", patient_id);
        Patient patient = null;
        try {
            patient = tq.getSingleResult();
            System.out.println(patient.getPatient_id() + " " + patient.getPn() + " " + patient.getFirst() + " " + patient.getLast() + " " + patient.getDob());
        } catch (NoResultException ex) {
            ex.printStackTrace();
        } finally {
            em.close();
        }

    }

    public static String findByNameAndLastName(String first, String last) {
        String sql = "FROM Patient p WHERE p.first = :n AND p.last = :l";
        EntityManager entityManager= ENTITY_MANAGER_FACTORY.createEntityManager();
        return entityManager
                .createQuery(sql, Patient.class)
                .setParameter("n", first)
                .setParameter("l", last)
                .getResultList().toString();
    }
}
