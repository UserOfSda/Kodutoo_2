create database test_task_database;
use test_task_database;
create table patient(
	patient_id int(10) UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
    pn varchar(11) NULL,
    first varchar(15) NULL,
    last varchar(25) NULL,
    dob date NULL
);
create table insurance(
	insurance_id int(10) UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
    patient_id int(10) UNSIGNED NOT NULL,
    iname varchar(40) NULL,
    from_date date NULL,
    to_date date NULL,
    FOREIGN KEY (patient_id) REFERENCES test_task_database.patient (patient_id)
);
insert into patient values
(1,"000000001","John","Smith","1981-01-02"),
(2,"000000002","John","Smith","1975-05-06"),
(3,"000000003","John","Doe","1990-10-11"),
(4,"000000004","John","Doe","1970-11-12"),
(5,"000000005","Gil","Johnson","1966-06-07");
insert into insurance values
(1,"1","Medicare","2009-01-01","2010-01-01"),
(2,"1","Blue Cross","2008-01-01","2009-01-01"),
(3,"2","Blue Shield","2010-01-01","2011-01-01"),
(4,"2","Blue Cross","2011-01-01","2012-01-01"),
(5,"3","Blue Shield","2009-01-01","2010-01-01"),
(6,"3","Medicare","2010-01-01","2011-01-01"),
(7,"4","Blue Shield","2012-01-01","2013-01-01"),
(8,"4","Blue Shield","2013-01-01","2014-01-01"),
(9,"5","Medicare","2010-01-01","2011-01-01"),
(10,"5","Medicare","2011-01-01","2012-01-01");


